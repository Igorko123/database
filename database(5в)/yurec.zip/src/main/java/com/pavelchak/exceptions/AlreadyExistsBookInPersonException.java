package com.pavelchak.exceptions;

public class AlreadyExistsBookInPersonException extends Exception {
}
