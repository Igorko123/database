package com.pavelchak.exceptions;

public class ExistsBooksForPersonException extends Exception {
}
