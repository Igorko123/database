package com.pavelchak.exceptions;

public class NoSuchPersonException extends Exception {
}
