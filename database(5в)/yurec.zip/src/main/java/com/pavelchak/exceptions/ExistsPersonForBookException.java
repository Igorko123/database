package com.pavelchak.exceptions;

public class ExistsPersonForBookException extends Exception {
}
