package com.pavelchak.exceptions;

public class NoSuchBookException extends Exception {
}
