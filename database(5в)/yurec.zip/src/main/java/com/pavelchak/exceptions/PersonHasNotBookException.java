package com.pavelchak.exceptions;

public class PersonHasNotBookException extends Exception {
}
