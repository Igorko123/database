package com.pavelchak.exceptions;

public class BookAbsentException extends Exception {
}
