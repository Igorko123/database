package com.pavelchak.exceptions;

public class NoSuchCityException extends Exception {
}
