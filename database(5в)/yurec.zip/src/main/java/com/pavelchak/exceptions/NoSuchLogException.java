package com.pavelchak.exceptions;

public class NoSuchLogException extends Exception {
}
