package com.pavelchak.exceptions;

public class ExistsPersonsForCityException extends Exception {
}
